import { Helmet } from 'react-helmet-async';

const SITE_NAME = 'Ed Weatherhead Jewellery';

// TODO: this whole page is placeholder text. Replace each section with
// your actual policy before going live — customers see this link at
// checkout, and clear shipping/returns terms are expected practice for
// online stores in Australia.
export default function ShippingReturns() {
  return (
    <section className="container" style={{ position: 'relative', zIndex: 1, padding: 'var(--space-5) var(--space-3)' }}>
      <Helmet>
        <title>Shipping &amp; returns — {SITE_NAME}</title>
      </Helmet>

      <p className="eyebrow">Policies</p>
      <h1 style={{ fontSize: 'var(--size-xl)' }}>Shipping &amp; returns</h1>

      <h2>Shipping</h2>
      <p>[Placeholder — describe your dispatch timeframe, e.g. "Orders are dispatched within 3 business days," which carrier you use, and whether parcels are tracked and/or insured.]</p>

      <h2>Returns &amp; exchanges</h2>
      <p>[Placeholder — describe your change-of-mind policy, e.g. whether you accept returns within a set number of days, who pays return postage, and the condition items must be in.]</p>

      <h2>Faulty items</h2>
      <p>[Placeholder — describe how a customer should contact you about a fault or damage in transit, and what you'll do about it.]</p>

      <p>Nothing in this policy affects your rights under the Australian Consumer Law, which provide consumer guarantees that can't be excluded.</p>
    </section>
  );
}
